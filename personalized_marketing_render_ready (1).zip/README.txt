
# Personalized Marketing Recommendation Engine (Enhanced)

## Setup Instructions

1. Make sure Python 3 and pip are installed.
2. Install the required packages:
   pip install flask scikit-learn numpy

3. Run the application:
   python app.py

4. Test the endpoint using POST request at:
   http://127.0.0.1:5000/recommend

   Sample JSON body:
   {
     "user": [0.8, 0.2, 0.6],
     "products": {
       "product_A": [0.9, 0.1, 0.7],
       "product_B": [0.4, 0.5, 0.3],
       "product_C": [0.6, 0.2, 0.8]
     }
   }

## Description
- Computes cosine similarity between the user profile and product vectors.
- Returns the top 5 recommended products based on similarity.
