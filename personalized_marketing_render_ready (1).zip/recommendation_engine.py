
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity

def recommend_products(user_profile, product_data):
    # Convert user profile and products to numpy arrays
    user_vector = np.array(user_profile).reshape(1, -1)
    product_ids = list(product_data.keys())
    product_vectors = np.array(list(product_data.values()))
    
    # Compute cosine similarity
    similarities = cosine_similarity(user_vector, product_vectors).flatten()
    
    # Create a dictionary of product scores
    scores = {product_ids[i]: float(similarities[i]) for i in range(len(product_ids))}
    
    # Sort and return top 5 recommendations
    sorted_scores = dict(sorted(scores.items(), key=lambda item: item[1], reverse=True)[:5])
    return sorted_scores
